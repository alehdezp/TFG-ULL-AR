public void onCreate(SQLiteDatabase db) {
    ... // Creación de la tabla SENDEROS 
    String CREATE_PUNTOS_TABLE = "CREATE TABLE " +
            TABLE_PUNTOS             + "("
            + COLUMN_NOMBRE_SENDERO  + " TEXT NOT NULL,"
            + COLUMN_ORDEN           + " INTEGER NOT NULL,"
            + COLUMN_LATITUD         + " REAL, "
            + COLUMN_LONGITUD        + " REAL, "
            + COLUMN_ELEVACION       + " REAL, "
            + COLUMN_TIEMPO          + " TEXT, "
            + COLUMN_DISTANCIA       + " REAL, "
            + COLUMN_NUBE            + " TEXT, "
            + "PRIMARY KEY (" + COLUMN_NOMBRE_SENDERO + ", " + COLUMN_ORDEN + ", " + COLUMN_NUBE + ") "
            + "FOREIGN KEY (" + COLUMN_NOMBRE_SENDERO + ") REFERENCES " + TABLE_SENDEROS + "(" + COLUMN_NOMBRE_SENDERO +")"
            + ")";
    db.execSQL(CREATE_SENDEROS_TABLE);
    db.execSQL(CREATE_PUNTOS_TABLE);
}