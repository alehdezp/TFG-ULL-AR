public class GPXData implements Serializable{
    private String nombreSendero;
    private String descSendero;
    private Punto[] puntos;
    private double alturaMinima;
    private double alturaMaxima;
    private double gananciaAltitud;
    private double perdidaAltitud;
    private double distancia;

    public GPXData(String nS, String dS, Punto[] p) {
        setNombreSendero(nS);
        setDescSendero(dS);
        setPuntos(p);
        ...  
        /* Cálculo de altura mínima y máxima, ganancia y pérdida de 
         * altitud, y distancia del sendero */         
    }
}
