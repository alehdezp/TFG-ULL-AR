protected String doInBackground(String... path) {
    try
    {
       GPXParser gpx = new GPXParser(path[0]);
       ruta = gpx.getDatos();
       changeMessage("Actualizando la base de datos...");
       DBHandler db = new DBHandler(context);
       if (!db.isGuardado(ruta)) {
           db.insertRapido(ruta);
           mensaje = "La base de datos fue actualizada correctamente";
       } else {
           mensaje = "Ya existe un sendero con ese nombre";
       }
    }
    catch (Exception ex)
    {
       Log.e("Ficheros", "Error al leer fichero desde memoria interna \n" + ex.getMessage());
       mensaje = "Error al leer el fichero desde memoria interna";
    }
    return mensaje;
}