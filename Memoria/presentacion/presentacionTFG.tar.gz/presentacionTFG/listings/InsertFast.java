public void insertRapido(GPXData gpx) {
    SQLiteDatabase db = this.getWritableDatabase();
    String insert_send_ini = "INSERT INTO " + TABLE_SENDEROS + " VALUES (";
    String descripcion_prev = cambiarCaracter(gpx.getDescSendero(), '\'', '.');
    String descripcion = descripcion_prev;
    String insert_send = insert_send_ini
            + "'" + gpx.getNombreSendero()     + "', "
            + "'" + descripcion                    + "', "
            + gpx.getPuntos()[0].getLatitud()  + ", "
            + gpx.getPuntos()[0].getLongitud()  + ", "
            + gpx.getAlturaMinima() + ", "
            + gpx.getAlturaMaxima() + ", "
            + gpx.getPerdidaAltitud() + ", "
            + gpx.getGananciaAltitud() + ", "
            + gpx.getDistancia() + ", "
            + "'" + "NO" + "', "
            + "'" + "NO" + "')";
    db.execSQL(insert_send);
    ... // INSERT en la tabla PUNTOS
}