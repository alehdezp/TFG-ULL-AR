public void onCreate(SQLiteDatabase db) {
    String CREATE_SENDEROS_TABLE = "CREATE TABLE " +
            TABLE_SENDEROS + "("
            + COLUMN_NOMBRE_SENDERO  + " TEXT,"
            + COLUMN_DESCRIPCION     + " TEXT,"
            + COLUMN_LAT_INI         + " REAL,"
            + COLUMN_LON_INI         + " REAL,"
            + COLUMN_ALT_MIN         + " REAL,"
            + COLUMN_ALT_MAX         + " REAL,"
            + COLUMN_PER_ALT         + " REAL,"
            + COLUMN_GAN_ALT         + " REAL,"
            + COLUMN_DISTANCIA       + " REAL,"
            + COLUMN_SUBIDO          + " TEXT,"
            + COLUMN_NUBE            + " TEXT,"
            + "PRIMARY KEY (" + COLUMN_NOMBRE_SENDERO + ", " + COLUMN_NUBE + ")) ";

    // Creación de la tabla PUNTOS
}